import * as style0 from "C:/Users/User/Mendix/Atrina-main/themesource/administration/native/main";
import * as style1 from "C:/Users/User/Mendix/Atrina-main/themesource/externaldatabaseconnector/native/main";
import * as style2 from "C:/Users/User/Mendix/Atrina-main/themesource/feedbackmodule/native/main";
import * as style3 from "C:/Users/User/Mendix/Atrina-main/themesource/nanoflowcommons/native/main";
import * as style4 from "C:/Users/User/Mendix/Atrina-main/themesource/atlas_core/native/main";
import * as style5 from "C:/Users/User/Mendix/Atrina-main/themesource/home/native/main";
import * as style6 from "C:/Users/User/Mendix/Atrina-main/theme/native/main";

import { flatten } from "mendix/native";

module.exports = flatten([style0, style1, style2, style3, style4, style5, style6]);
